<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <style>
                        body {
                margin: 0; padding: 0;
            }
            .background {
                margin: 0;
                padding: 0;
                background-color: rgb(255, 182, 194) !important;
            }
            .bg {
                background-color: rgb(210, 219, 255) !important;
            }
        </style>
        <link rel="stylesheet" href="style.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
    </head>
    <body>
    <div class="main-wrapper d-flex justify-content-center align-items-center background" style="min-height: 100vh;">
    <div class="d-inline-block text-center bg px-5 py-4 rounded" style="min-width: 400px;">
    <h2>Beranda</h2>
    <p>Halo, perkenalkan saya <?= $nama ?> dari program studi <?= $asal_prodi ?>.</p>
    <p>Berikut adalah informasi singkat tentang saya:</p>
    
    <img src="<?= base_url('images/' . $gambar) ?>" alt="Foto Profil" width="150">
    <div><strong>NIM:</strong> <?= $nim ?></div>
    <a href="<?= base_url('profil'); ?>" class="btn py-2 px-4 background">Profil</a>
    </div>
    </div>
</body>
</html>
