<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <style>
            body {
                margin: 0; padding: 0;
            }
            .background {
                margin: 0;
                padding: 0;
                background-color: rgb(255, 182, 194) !important;
            }
            .bg {
                background-color: rgb(210, 219, 255) !important;
            }
        </style>
        <link rel="stylesheet" href="./style.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
    </head>
<body>
  <div class="main-wrapper d-flex justify-content-center align-items-center background" style="min-height: 100vh;">
    <div class="d-inline-block text-center bg px-5 py-4 rounded-4" style="min-width: 600px;">
      <h2>Profil</h2>

      <p><strong>Foto Profil:</strong></p>
      <img src="<?= base_url('images/' . $gambar) ?>" alt="Foto Profil" width="300">

      <table class="table-centered mx-auto">
        <tr>
          <td><strong>Nama</strong></td>
          <td>: <?= $nama ?></td>
        </tr>
        <tr>
          <td><strong>NIM</strong></td>
          <td>: <?= $nim ?></td>
        </tr>
        <tr>
          <td><strong>Program Studi</strong></td>
          <td>: <?= $asal_prodi ?></td>
        </tr>
        <tr>
          <td><strong>Hobi</strong></td>
          <td>: <?= $hobi ?></td>
        </tr>
        <tr>
          <td><strong>Skill</strong></td>
          <td>: <?= $skill ?></td>
        </tr>
        <tr>
          <td><strong>Cita-cita</strong></td>
          <td>: <?= $cita2 ?></td>
        </tr>
        <tr>
          <td><strong>Zodiak</strong></td>
          <td>: <?= $zodiak ?></td>
        </tr>
      </table>
    </div>
  </div>
</body>
</html>