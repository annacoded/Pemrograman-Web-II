<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Website Biodata</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px;}
        nav a { margin-right: 15px; text-decoration: none; color: black; }
        .bg {
            background-color: rgb(210, 219, 255) !important;
            padding: 15px !important;
        }
    </style>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
</head>
<body>
<nav class="navbar navbar-expand-lg">
    <div class="container d-flex flex-row justify-content-center">
        <a href="<?= base_url('home') ?>" class="nav-link btn bg">Beranda</a>
    <a href="<?= base_url('profil') ?>" class="nav-link btn bg">Profil</a>
    </div>
</nav>
</body>
</html>
