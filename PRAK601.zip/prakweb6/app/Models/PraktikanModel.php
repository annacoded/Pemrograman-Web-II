<?php

namespace App\Models;
use CodeIgniter\Model;

class PraktikanModel extends Model{
    public function getData(){
        return [
            'nama' => 'Siti Ratna Dwinta Sari',
            'gambar' => 'anna.jpeg',
            'nim' => '2310817120002',
            'asal_prodi' => 'Teknologi Informasi',
            'hobi' => 'Mendengarkan Musik',
            'skill' => 'Editing',
            'cita2' => 'Astronot NASA',
            'zodiak' => 'Capricorn'
        ];
    }
}