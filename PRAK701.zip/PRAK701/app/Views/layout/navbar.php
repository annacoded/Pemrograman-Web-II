<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ghibli Navbar</title>
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Comic+Neue:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --ghibli-blue: #A7C5EB;
            --ghibli-green: #B8E986;
            --ghibli-yellow: #F9F3A3;
            --ghibli-cream: #FEF6E4;
            --ghibli-brown: #6D4C41;
            --ghibli-red: #FF6B6B;
        }
        
        .ghibli-navbar {
            background-color: var(--ghibli-blue) !important;
            padding: 10px 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-bottom: 2px dashed white;
        }
        
        .navbar-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .nav-icons {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        
        .icon-link {
            display: inline-block;
            transition: all 0.3s;
            padding: 8px;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.2);
        }
        
        .icon-link:hover {
            background-color: rgba(255, 255, 255, 0.4);
            transform: translateY(-3px) scale(1.1);
        }
        
        .icon-link svg {
            width: 32px;
            height: 32px;
            vertical-align: middle;
        }
        
        .home-icon {
            fill: var(--ghibli-brown);
        }
        
        .logout-icon {
            fill: var(--ghibli-red);
        }
        
        .nav-title {
            font-family: 'Fredoka One', cursive;
            color: white;
            text-shadow: 2px 2px 0px var(--ghibli-brown);
            margin: 0;
            font-size: 1.8rem;
        }
        
        .totoro-decoration {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            bottom: -15px;
            height: 60px;
            opacity: 0.8;
        }
    </style>
</head>
<body>
    <nav class="ghibli-navbar sticky-top">
        <div class="navbar-container">
            <div class="nav-icons">
                <a href="<?= site_url('/') ?>" class="icon-link" title="Home">
                    <svg class="home-icon" viewBox="0 -960 960 960">
                        <path d="M240-200h120v-240h240v240h120v-360L480-740 240-560v360Zm-80 80v-480l320-240 320 240v480H520v-240h-80v240H160Zm320-350Z"/>
                    </svg>
                </a>
            </div>
            
            <h1 class="nav-title">📚Welcome!</h1>
            
            <div class="nav-icons">
                <a href="<?= site_url('user/logout') ?>" class="icon-link" title="Logout">
                    <svg class="logout-icon" viewBox="0 -960 960 960">
                        <path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/>
                    </svg>
                 </a>
    </nav>
</body>
</html>