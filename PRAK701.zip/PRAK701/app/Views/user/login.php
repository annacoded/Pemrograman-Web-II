<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login - Ghibli</title>
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Comic+Neue:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --ghibli-bg: #f5f5f5;
            --ghibli-input: #fff4dc;
            --ghibli-btn-blue: #a3c4f3;
            --ghibli-btn-yellow: #fdf5a6;
            --ghibli-border: #ccc;
            --ghibli-brown: #5d4037;
            --ghibli-error: #ff6b6b;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: 'Fredoka One', cursive;
            background-color: var(--ghibli-bg);
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        .login-container {
            background-color: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }

        h2 {
            font-family: 'Fredoka One', cursive;
            font-size: 28px;
            color: var(--ghibli-brown);
            text-align: center;
            margin-bottom: 30px;
        }

        label {
            font-weight: bold;
            color: var(--ghibli-brown);
        }

        .form-group {
            margin-bottom: 20px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            font-size: 16px;
            background-color: var(--ghibli-input);
            border: 2px solid var(--ghibli-border);
            border-radius: 8px;
            outline: none;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: var(--ghibli-btn-blue);
        }

        .login-button {
            width: 100%;
            padding: 12px;
            font-size: 16px;
            font-weight: bold;
            color: white;
            background-color: var(--ghibli-btn-blue);
            border: none;
            border-radius: 25px;
            cursor: pointer;
        }

        .login-button:hover {
            background-color: #8fb3e2;
        }

        .error-message {
            background-color: var(--ghibli-error);
            color: white;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
    </style>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
</head>
<body>
    <div class="container mt-5 col-5">
        <div class="card p-3 m-auto bg-secondary-subtle">
            <h2>🔑Login🔑</h2>
            <div class="card-body">
                <form action="<?= base_url('user/login') ?>" method="POST">
                    <?= csrf_field() ?>
                    <?php if (session()->getFlashdata('error')): ?>
                        <div class="alert alert-danger">
                            <?= session()->getFlashdata('error') ?>
                        </div>
                    <?php endif; ?>
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" value="<?php echo session()->getFlashdata('username'); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password">
                    </div>
                    <button type="submit" class="btn btn-primary" id="login" name="login" value="login">Login</button>
                </form>
        </div>
    </div>
</body>
</html>