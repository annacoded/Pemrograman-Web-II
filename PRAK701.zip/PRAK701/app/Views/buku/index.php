<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perpustakaan Ghibli</title>
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Comic+Neue:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --ghibli-blue: #A7C5EB;
            --ghibli-green: #B8E986;
            --ghibli-yellow: #F9F3A3;
            --ghibli-cream: #FEF6E4;
            --ghibli-brown: #6D4C41;
        }
        
        body {
            font-family: 'Comic Neue', cursive;
            background-color: var(--ghibli-cream);
            color: var(--ghibli-brown);
            margin: 0;
            padding: 20px;
            background-image: url(https://pin.it/3b1yGCY5u);
            background-size: 300px;
            background-repeat: repeat;
            background-attachment: fixed;
            background-blend-mode: overlay;
            background-position: center;
        }
        
        h2 {
            font-family: 'Fredoka One', cursive;
            color: #5D4037;
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 30px;
            text-shadow: 2px 2px 0px var(--ghibli-yellow);
        }
        
        .container {
            max-width: 1000px;
            margin: 0 auto;
            background-color: rgba(255, 255, 255, 0.85);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            border: 2px dashed var(--ghibli-blue);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: white;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid var(--ghibli-blue);
        }
        
        th {
            background-color: var(--ghibli-blue);
            color: white;
            font-family: 'Fredoka One', cursive;
        }
        
        tr:nth-child(even) {
            background-color: var(--ghibli-yellow);
        }
        
        tr:hover {
            background-color: var(--ghibli-green);
        }
        
        a {
            color: #5D4037;
            text-decoration: none;
            font-weight: bold;
            padding: 8px 12px;
            border-radius: 20px;
            transition: all 0.3s;
        }
        
        a:hover {
            background-color: var(--ghibli-blue);
            color: white;
        }
        
        .success-message {
            background-color: var(--ghibli-green);
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: bold;
        }
        
        .add-button {
            display: inline-block;
            background-color: var(--ghibli-blue);
            color: white !important;
            padding: 10px 20px;
            border-radius: 30px;
            margin-bottom: 20px;
            box-shadow: 0 3px 5px rgba(0, 0, 0, 0.2);
        }
        
        .add-button:hover {
            background-color: #8FB2D9;
            transform: translateY(-2px);
        }
        
        .action-links {
            display: flex;
            gap: 10px;
        }
        
        .action-links a {
            display: flex;
            align-items: center;
            gap: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>📚 Perpustakaan Ghibli</h2>
        
        <?php if (session()->getFlashdata('success')): ?>
            <div class="success-message">
                🌟 <?= session()->getFlashdata('success') ?>
            </div>
        <?php endif; ?>
        
        <div>
            <a href="<?= base_url('buku/create') ?>" class="add-button">+ Tambah Buku Baru</a>
        </div>
        
        <?php if (!empty($buku) && is_array($buku)): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Judul</th>
                    <th>Penulis</th>
                    <th>Penerbit</th>
                    <th>Tahun Terbit</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($buku as $b): ?>
                    <tr>
                        <td><?= esc($b['id']) ?></td>
                        <td><?= esc($b['judul']) ?></td>
                        <td><?= esc($b['penulis']) ?></td>
                        <td><?= esc($b['penerbit']) ?></td>
                        <td><?= esc($b['tahun_terbit']) ?></td>
                        <td class="action-links">
                            <a href="<?= site_url('buku/edit/' . $b['id']) ?>">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="#5D4037">
                                    <path d="M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z"/>
                                </svg>
                                Edit
                            </a>
                            <a href="<?= site_url('buku/delete/' . $b['id']) ?>">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="#5D4037">
                                    <path d="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z"/>
                                </svg>
                                Hapus
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
            <div style="text-align: center; padding: 40px; background-color: var(--ghibli-yellow); border-radius: 10px;">
                <p style="font-size: 1.2rem;">Tidak ada data buku. Mari tambahkan buku pertama!</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>