<?php 
    $errors = session()->get('errors') ?? []; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Buku - Ghibli</title>
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Comic+Neue:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --ghibli-blue: #A7C5EB;
            --ghibli-green: #B8E986;
            --ghibli-yellow: #F9F3A3;
            --ghibli-cream: #FEF6E4;
            --ghibli-brown: #6D4C41;
        }
        
        body {
            font-family: 'Comic Neue', cursive;
            background-color: var(--ghibli-cream);
            color: var(--ghibli-brown);
            margin: 0;
            padding: 20px;
            background-image: url('https://unsplash.com/photos/red-haired-girl-in-green-dress-figurine-on-green-grass-during-daytime-eTMtdh85TOk');
            background-size: 3px;
            background-repeat: repeat;
            background-attachment: fixed;
            background-position: center;
        }
        
        h2 {
            font-family: 'Fredoka One', cursive;
            color: #5D4037;
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 30px;
            text-shadow: 2px 2px 0px var(--ghibli-yellow);
        }
        
        .form-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            border: 2px dashed var(--ghibli-blue);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: var(--ghibli-brown);
        }
        
        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 12px;
            border: 2px solid var(--ghibli-blue);
            border-radius: 8px;
            font-size: 16px;
            background-color: var(--ghibli-cream);
            transition: all 0.3s;
        }
        
        input[type="text"]:focus,
        input[type="number"]:focus {
            outline: none;
            border-color: var(--ghibli-green);
            box-shadow: 0 0 0 3px rgba(184, 233, 134, 0.3);
        }
        
        .error-message {
            color: #E53935;
            font-size: 14px;
            margin-top: 5px;
        }
        
        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        
        button, .button {
            padding: 12px 25px;
            border: none;
            border-radius: 30px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        button {
            background-color: var(--ghibli-blue);
            color: white;
        }
        
        button:hover {
            background-color: #8FB2D9;
            transform: translateY(-2px);
        }
        
        .button {
            background-color: var(--ghibli-yellow);
            color: var(--ghibli-brown);
            text-decoration: none;
        }
        
        .button:hover {
            background-color: #E6E08C;
            transform: translateY(-2px);
        }
        
        .ghibli-decoration {
            text-align: center;
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>✨ Tambah Buku Baru</h2>
        
        <form action="<?= base_url('buku/save') ?>" method="POST">
            <?= csrf_field() ?>
            
            <div class="form-group">
                <label for="judul">Judul Buku</label>
                <input type="text" id="judul" name="judul" value="<?= old('judul') ?>">
                <?php if(isset($errors['judul'])): ?>
                <div class="error-message">
                    <?= $errors['judul'] ?>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="penulis">Penulis</label>
                <input type="text" id="penulis" name="penulis" value="<?= old('penulis') ?>">
                <?php if(isset($errors['penulis'])): ?>
                <div class="error-message">
                    <?= $errors['penulis'] ?>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="penerbit">Penerbit</label>
                <input type="text" id="penerbit" name="penerbit" value="<?= old('penerbit') ?>">
                <?php if(isset($errors['penerbit'])): ?>
                <div class="error-message">
                    <?= $errors['penerbit'] ?>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="tahun_terbit">Tahun Terbit</label>
                <input type="number" id="tahun_terbit" name="tahun_terbit" value="<?= old('tahun_terbit') ?>">
                <?php if(isset($errors['tahun_terbit'])): ?>
                <div class="error-message">
                    <?= $errors['tahun_terbit'] ?>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="button-group">
                <button type="submit">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
                        <path d="M17 3H5C3.89 3 3 3.9 3 5V19C3 20.1 3.89 21 5 21H19C20.1 21 21 20.1 21 19V7L17 3ZM19 19H5V5H16.17L19 7.83V19ZM12 12C10.34 12 9 13.34 9 15C9 16.66 10.34 18 12 18C13.66 18 15 16.66 15 15C15 13.34 13.66 12 12 12ZM6 6H15V10H6V6Z"/>
                    </svg>
                    Simpan
                </button>
                <a href="<?= site_url('/') ?>" class="button">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="#5D4037">
                        <path d="M20 11H7.83L13.42 5.41L12 4L4 12L12 20L13.41 18.59L7.83 13H20V11Z"/>
                    </svg>
                    Kembali
                </a>
            </div>
        </form>
    </div>
</body>
</html>